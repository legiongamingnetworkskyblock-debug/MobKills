package com.lgn.mobkills;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Statistic;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public final class MobKills extends JavaPlugin implements Listener {
    private record Mob(EntityType type, Material icon, String label) {}
    private static final List<Mob> MOBS = List.of(
        new Mob(EntityType.BLAZE, Material.BLAZE_ROD, "Blaze"),
        new Mob(EntityType.BOGGED, Material.BONE, "Bogged"),
        new Mob(EntityType.BREEZE, Material.BREEZE_ROD, "Breeze"),
        new Mob(EntityType.CAVE_SPIDER, Material.SPIDER_EYE, "Cave Spider"),
        new Mob(EntityType.CREEPER, Material.CREEPER_HEAD, "Creeper"),
        new Mob(EntityType.DROWNED, Material.TRIDENT, "Drowned"),
        new Mob(EntityType.ELDER_GUARDIAN, Material.PRISMARINE_SHARD, "Elder Guardian"),
        new Mob(EntityType.ENDERMAN, Material.ENDER_PEARL, "Enderman"),
        new Mob(EntityType.ENDERMITE, Material.END_STONE, "Endermite"),
        new Mob(EntityType.EVOKER, Material.TOTEM_OF_UNDYING, "Evoker"),
        new Mob(EntityType.GHAST, Material.GHAST_TEAR, "Ghast"),
        new Mob(EntityType.GUARDIAN, Material.PRISMARINE_CRYSTALS, "Guardian"),
        new Mob(EntityType.HOGLIN, Material.PORKCHOP, "Hoglin"),
        new Mob(EntityType.HUSK, Material.SAND, "Husk"),
        new Mob(EntityType.MAGMA_CUBE, Material.MAGMA_CREAM, "Magma Cube"),
        new Mob(EntityType.PHANTOM, Material.PHANTOM_MEMBRANE, "Phantom"),
        new Mob(EntityType.PIGLIN, Material.GOLDEN_SWORD, "Piglin"),
        new Mob(EntityType.PIGLIN_BRUTE, Material.GOLDEN_AXE, "Piglin Brute"),
        new Mob(EntityType.PILLAGER, Material.CROSSBOW, "Pillager"),
        new Mob(EntityType.RAVAGER, Material.SADDLE, "Ravager"),
        new Mob(EntityType.SHULKER, Material.SHULKER_SHELL, "Shulker"),
        new Mob(EntityType.SILVERFISH, Material.INFESTED_STONE, "Silverfish"),
        new Mob(EntityType.SKELETON, Material.SKELETON_SKULL, "Skeleton"),
        new Mob(EntityType.SLIME, Material.SLIME_BALL, "Slime"),
        new Mob(EntityType.SPIDER, Material.SPIDER_EYE, "Spider"),
        new Mob(EntityType.STRAY, Material.TIPPED_ARROW, "Stray"),
        new Mob(EntityType.VEX, Material.IRON_SWORD, "Vex"),
        new Mob(EntityType.VINDICATOR, Material.IRON_AXE, "Vindicator"),
        new Mob(EntityType.WARDEN, Material.SCULK_CATALYST, "Warden"),
        new Mob(EntityType.WITCH, Material.POTION, "Witch"),
        new Mob(EntityType.WITHER, Material.WITHER_SKELETON_SKULL, "Wither"),
        new Mob(EntityType.WITHER_SKELETON, Material.WITHER_SKELETON_SKULL, "Wither Skeleton"),
        new Mob(EntityType.ZOGLIN, Material.ROTTEN_FLESH, "Zoglin"),
        new Mob(EntityType.ZOMBIE, Material.ZOMBIE_HEAD, "Zombie"),
        new Mob(EntityType.ZOMBIE_VILLAGER, Material.ZOMBIE_HEAD, "Zombie Villager"),
        new Mob(EntityType.ZOMBIFIED_PIGLIN, Material.GOLD_NUGGET, "Zombified Piglin"),
        new Mob(EntityType.ENDER_DRAGON, Material.DRAGON_HEAD, "Ender Dragon")
    );
    private static final int PAGE_SIZE = 28;
    private static final int[] SLOTS = {10,11,12,13,14,15,16,19,20,21,22,23,24,25,28,29,30,31,32,33,34,37,38,39,40,41,42,43};
    private static final class MenuHolder implements InventoryHolder {
        final int page;
        Inventory inventory;
        MenuHolder(int page) { this.page = page; }
        @Override public Inventory getInventory() { return inventory; }
    }
    @Override public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getCommand("mobs").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
            open(player, 0);
            return true;
        });
    }
    private ItemStack item(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        meta.setLore(Arrays.stream(lore).map(s -> ChatColor.translateAlternateColorCodes('&', s)).toList());
        item.setItemMeta(meta);
        return item;
    }
    private int kills(Player player, EntityType type) {
        try { return player.getStatistic(Statistic.KILL_ENTITY, type); }
        catch (IllegalArgumentException ex) { return 0; }
    }
    private void open(Player player, int page) {
        int pages = (MOBS.size() + PAGE_SIZE - 1) / PAGE_SIZE;
        page = Math.max(0, Math.min(page, pages - 1));
        MenuHolder holder = new MenuHolder(page);
        Inventory inv = Bukkit.createInventory(holder, 54, ChatColor.DARK_GRAY + "☠ Mob Kills " + ChatColor.GRAY + "(" + (page + 1) + "/" + pages + ")");
        holder.inventory = inv;
        ItemStack border = item(Material.GRAY_STAINED_GLASS_PANE, "&8 ");
        for (int i = 0; i < 54; i++) inv.setItem(i, border);
        for (int i = 0; i < PAGE_SIZE; i++) {
            int index = page * PAGE_SIZE + i;
            if (index >= MOBS.size()) break;
            Mob mob = MOBS.get(index);
            int count = kills(player, mob.type());
            inv.setItem(SLOTS[i], item(mob.icon(), "&c&l" + mob.label(),
                "&8&m-----------------------", "&7Your kills: &a&l" + String.format("%,d", count),
                "&7Mob: &f" + mob.label(), "", "&e⚔ Keep hunting to increase", "&eyour personal kill count!", "&8&m-----------------------"));
        }
        int total = MOBS.stream().mapToInt(m -> kills(player, m.type())).sum();
        inv.setItem(4, item(Material.NETHER_STAR, "&6&lYour Mob Statistics", "&7Player: &f" + player.getName(), "&7Total hostile kills: &a" + String.format("%,d", total), "", "&eStats are tracked by Minecraft."));
        inv.setItem(45, item(Material.ARROW, "&ePrevious Page", "&7Click to go back."));
        inv.setItem(49, item(Material.BARRIER, "&cClose Menu", "&7Click to close."));
        inv.setItem(53, item(Material.ARROW, "&eNext Page", "&7Click to see more mobs."));
        if (page == 0) inv.setItem(45, border);
        if (page == pages - 1) inv.setItem(53, border);
        player.openInventory(inv);
    }
    @EventHandler public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;
        int slot = event.getRawSlot();
        if (slot == 49) player.closeInventory();
        else if (slot == 45 && holder.page > 0) open(player, holder.page - 1);
        else if (slot == 53 && (holder.page + 1) * PAGE_SIZE < MOBS.size()) open(player, holder.page + 1);
    }
    @EventHandler public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof MenuHolder) event.setCancelled(true);
    }
}
